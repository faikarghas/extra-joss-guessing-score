function getCurrentDate(date: Date){
    const d = new Date()

    return `date ${d}`
}

export {
    getCurrentDate
}