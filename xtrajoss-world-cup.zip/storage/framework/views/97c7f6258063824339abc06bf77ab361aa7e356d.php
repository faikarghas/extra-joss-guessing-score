
<?php $__env->startSection('title'); ?>
    <?php  
        $postId = last(request()->segments());
    ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<?php echo e(Breadcrumbs::render('posts')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Basic Bootstrap Table -->
<div class="card">
   <h5 class="card-header">List Matchs</h5>
   <div class="table-responsive text-nowrap">
     <table class="table">
       <thead>
         <tr>
           <th>Team A</th>
           <th>Team B</th>
           <th>Result</th>
           <th>Round</th>
           <th>Match Status</th>
           <th>Match Time</th>
           <th>Status</th>
           <th>Actions</th>
         </tr>
       </thead>
       <tbody class="table-border-bottom-0">
         <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><strong><?php echo e($row->countries_one->name); ?></strong></td>
               <td><strong><?php echo e($row->countries_two->name); ?></strong></td>
               <td><?php echo e($row->score_a); ?> - <?php echo e($row->score_b); ?></td>
               <td><span class="badge rounded-pill bg-success me-1"><?php echo e($row->round_match->title); ?></span></td>
               <td><span class="badge rounded-pill bg-warning me-1"><?php echo e($row->match_status); ?></span></td>
               <td><span class="badge rounded-pill bg-primary me-1"><?php echo e($row->match_time); ?></span></td>
               <td>
                  
                     <div class="form-check form-switch mb-2">
                     <?php if($row->status == '1'): ?>
                     <input class="form-check-input" type="checkbox" data-id="<?php echo e($row->id); ?>" id="flexSwitchCheckDefault" name="status" value="0" checked/>
                     <?php else: ?>
                     <input class="form-check-input" type="checkbox" data-id="<?php echo e($row->id); ?>" id="flexSwitchCheckDefault" name="status" value="1"/>
                     <?php endif; ?>
                    
                  </div>
                  
               </td>
               <td>
                  <div class="dropdown">
                     <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                       <i class="bx bx-dots-vertical-rounded"></i>
                     </button>
                     <div class="dropdown-menu">
                       <a class="dropdown-item" href="<?php echo e(route('matchs.edit',[$row->id])); ?>"
                         ><i class="bx bx-edit-alt me-1"></i> Edit</a
                       >
                     </div>
                   </div>
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
     </table>
   </div>
 </div>
 <!--/ Basic Bootstrap Table -->
<?php $__env->stopSection(); ?> 
<?php $__env->startPush('javascript-internal'); ?>
   <script>
      $(document).ready(function(){

         $('.form-check-input').on('change',function(){

            var $this = $(this);
            
            
            $.ajax({
               url: '<?php echo e(route('matchs.updatestatus')); ?>',
               headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
               data: {
                   
                   data_id: $this.attr('data-id'),
                   checkboxStatus: $this.val(),
                 
               },
               type: 'POST',
               dataType: 'json',
               success: function (data) {
                  if (data.success) {
                            swal.fire("Done!", data.message, "success");
                            location.reload(2000);
                        } else {
                            swal.fire("Error!", 'Sumething went wrong.', "error");
                        }
                },
                error: function (data) {
                    alert('error handing here');
                    
                }
            });
         });

         // event delete category
         $("form[role='alert']").submit(function(event){
            event.preventDefault(); 
            Swal.fire({
               title: "Apakah anda ingin menghapus ?",
               text: $(this).attr('alert-text'),
               icon: 'warning',
               allowOutsideClick: false,
               showCancelButton: true,
               cancelButtonText: "Cancel",
               reverseButtons: true,
               confirmButtonText: "Yes",
            }).then((result) => {
               if (result.isConfirmed) {
                  // todo: process of deleting categories
                  event.target.submit(); 
               }
            });
         });
      });
   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/admin/match/index.blade.php ENDPATH**/ ?>