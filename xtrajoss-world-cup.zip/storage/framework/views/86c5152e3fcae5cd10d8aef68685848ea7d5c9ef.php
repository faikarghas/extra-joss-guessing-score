
<?php $__env->startSection('meta-tag'); ?>
<title></title>
<meta name="description" content="meta description">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<main>
    <div class="modal-register w-full  bg-[#FFEC00] px-9 lg:px-14 pt-9 lg:pt-20 pb-6">
        <div class="bg-white flex flex-wrap py-14 px-4 lg:px-20 relative justify-between">
            <div class="close-register absolute top-[-22px] right-[-22px] lg:top-[15px] lg:right-[15px] cursor-pointer">
                <a href="<?php echo e(route('home')); ?>" class="w-[44px] h-[44px] bg-black rounded-full flex items-center justify-center">
                    <img src="<?php echo e(asset('/images/close-w.png')); ?>" />
                </a>
            </div>
            <div class="basis-full flex flex-col lg:flex-row justify-between mb-8">
                <h2 class="font-head text-[60px] leading-[54px]">DAFTAR</h2>
                <h2 class="font-head text-[25px] lg:text-[60px] text-[#FFA800] flex leading-[54px] items-center">DAPATKAN <img class="mx-2 object-contain h-[36px]" src="<?php echo e(asset('/images/acv2.png')); ?>" />  60 Poin AWAL!</h2>
            </div>
            <div class="basis-full relative">
                <form class="flex flex-wrap justify-between" method="POST" action="<?php echo e(route('storeRegister')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="basis-full lg:basis-[48%] flex flex-wrap justify-between">
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="nama" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">NAMA*</label>
                            <input id="nama" type="text" name="name" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2  focus:outline-none focus:ring-0 focus:border-black-600 peer  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" required value="<?php echo e(old('name')); ?>">
                            <?php if($errors->has('name')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('name')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="email" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">ALAMAT EMAIL*</label>
                            <input id="email" type="email" name="email" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="user@example.net" required value="<?php echo e(old('email')); ?>">
                            <?php if($errors->has('email')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('email')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="username" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">USERNAME*</label>
                            <input id="username" type="text" name="username" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" required value="<?php echo e(old('username')); ?>" >
                            <?php if($errors->has('username')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('username')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">PASSWORD*</label>
                            <input id="password" type="password" name="password" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="" required>
                            <?php if($errors->has('password')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('password')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="instagram" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">AKUN INSTAGRAM</label>
                            <input id="instagram" type="text" name="account_instagram" class="font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2  focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="@">
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="phone" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">NO HANDPHONE*</label>
                            <input id="phone" type="tel" name="phone" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="" required value="<?php echo e(old('phone')); ?>">
                            <?php if($errors->has('phone')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('phone')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="basis-full lg:basis-[48%] flex flex-wrap justify-between">
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">KOTA*</label>
                            <select class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2  focus:outline-none focus:ring-0 focus:border-black-600 peer" name="city" id="provinsi" required value="<?php echo e(old('provinsi')); ?>">
                                <option value="">Pilih Provinsi</option>
                                <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <?php if($errors->has('provinsi')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('provinsi')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">KECAMATAN*</label>
                              <select name="city" id="city" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2  focus:outline-none focus:ring-0 focus:border-black-600 peer" required>
                                <option value="">Pilih Kota</option>
                            </select>
                            <?php if($errors->has('city')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('city')); ?></span>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">ALAMAT RUMAH*</label>
                            <input type="text" name="address" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="" required value="<?php echo e(old('address')); ?>">
                            <?php if($errors->has('address')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('address')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">UKURAN JERSEY*</label>
                            <input type="text" name="size_jersey" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="S, M, L, XL, XXL" required value="<?php echo e(old('size_jersey')); ?>">
                            <?php if($errors->has('size_jersey')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('size_jersey')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="self-start relative z-0 mb-6 w-full group basis-full lg:basis-[48%]">
                            <label for="password" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">UKURAN SEPATU*</label>
                            <input type="text" name="size_sepatu" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="36, 37, 38, 39, 40, 41, 42, 43, 44, 45" required value="<?php echo e(old('size_sepatu')); ?>">
                            <?php if($errors->has('size_sepatu')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('size_sepatu')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="basis-full">
                        <div class="self-start relative z-0 mb-6 w-full group basis-full">
                            <label for="nik" class="block mb-2 text-sm font-medium text-[#A0A0A0] dark:text-gray-300">NO IDENTITAS KEPENDUDUKAN*</label>
                            <input id="nik" type="text" name="nik" class="required font-sans block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 focus:outline-none focus:ring-0 focus:border-black-600 peer" placeholder="" required value="<?php echo e(old('nik')); ?>">
                            <?php if($errors->has('nik')): ?>
                                <div class="p-1 mt-2 text-[12px] text-red-700  role="alert">
                                <span class="font-medium"><?php echo e($errors->first('nik')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                  <button type="submit" class="bg-gray-200 text-gray-600 p-4 w-full font-sans">KIRIM</button>
                    <?php if($message = Session::get('email_duplicate')): ?>
                        <div class="p-4 mt-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800" role="alert">
                            <span class="font-medium"><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <div class="pb-14 pt-10">
            <img alt="logo extra joss" class="m-auto mb-2" src="<?php echo e(asset('/images/logo.png')); ?>"/>
            <p class="font-sans text-center text-[10px]">Copyright © 2022 ExtraJoss</p>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<script>

</script>
<?php echo $__env->make('web/components/layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/web/pages/register.blade.php ENDPATH**/ ?>