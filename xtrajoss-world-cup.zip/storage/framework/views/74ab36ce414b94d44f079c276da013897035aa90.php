
<?php $__env->startSection('meta-tag'); ?>
<title></title>
<meta name="description" content="meta description">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="relative h-full">
    <header class="relative info bg-no-repeat bg-cover bg-[#FFEC00]" >
        <?php echo $__env->make('web.components.presentational.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="relative z-20 m-auto lg:w-[95%] pt-[124px] md:pt-[85px] sm:pt-[130px] lg:pt-[160px] px-8">
            <div class="bg-[#202124]  pt-12 flex flex-col">
                <h1 class="text-white text-[60px] font-head mb-8 lg:pl-12 leading-[50px] px-4">HASIL PERTANDINGAN</h1>

                <div class="flex flex-col mb-12">
                    <div class="basis-full"><h3 class="font-sans text-white font-bold text-[20px] lg:pl-12 px-4">Putaran 1</h3></div>
                    <div class="flex flex-row flex-wrap lg:flex-nowrap gap-2">
                        <div class="basis-full flex flex-wrap bg-[#202124]">
                            <?php if(auth()->guard()->check()): ?>
                                <?php $__currentLoopData = $myguess1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                    <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                    <div class="flex flex-wrap">
                                        <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                            <li class="mb-2 flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                            </li>
                                            <li class="flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                            </li>
                                        </ul>
                                        <div class="basis-1/2 flex items-center justify-center">
                                            <ul class="score">
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                </li>
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                </li>
                                            </ul>
                                            <?php
                                                $datetime = date($match->match_time);
                                                $timestamp = strtotime($datetime);
                                                $time = $timestamp - (1 * 60 * 60);
                                                $datetime = date("Y-m-d H:i:s", $time);

                                                $d1 = new DateTime($currentTime);
                                                $d2 = new DateTime($datetime);
                                            ?>
                                            <?php if($d1 < $d2): ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php elseif($match->guessing_result == 0): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $matches1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                        <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                        <div class="flex flex-wrap">
                                            <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                <li class="mb-2 flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                </li>
                                                <li class="flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                </li>
                                            </ul>
                                            <div class="basis-1/2 flex items-center justify-center">
                                                <ul class="score">
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                    </li>
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col mb-12">
                    <div class="basis-full"><h3 class="font-sans text-white font-bold text-[20px] lg:pl-12 px-4">Putaran 2</h3></div>
                    <div class="flex flex-row flex-wrap lg:flex-nowrap gap-2">
                        <div class="basis-full flex flex-wrap bg-[#202124]">
                            <?php if(auth()->guard()->check()): ?>
                                <?php $__currentLoopData = $myguess2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                    <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                    <div class="flex flex-wrap">
                                        <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                            <li class="mb-2 flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                            </li>
                                            <li class="flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                            </li>
                                        </ul>
                                        <div class="basis-1/2 flex items-center justify-center">
                                            <ul class="score">
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                </li>
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                </li>
                                            </ul>
                                            <?php
                                                $datetime = date($match->match_time);
                                                $timestamp = strtotime($datetime);
                                                $time = $timestamp - (1 * 60 * 60);
                                                $datetime = date("Y-m-d H:i:s", $time);

                                                $d1 = new DateTime($currentTime);
                                                $d2 = new DateTime($datetime);
                                            ?>
                                            <?php if($d1 < $d2): ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php elseif($match->guessing_result == 0): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $matches2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                        <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                        <div class="flex flex-wrap">
                                            <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                <li class="mb-2 flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                </li>
                                                <li class="flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                </li>
                                            </ul>
                                            <div class="basis-1/2 flex items-center justify-center">
                                                <ul class="score">
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                    </li>
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col mb-12">
                    <div class="basis-full"><h3 class="font-sans text-white font-bold text-[20px] lg:pl-12 px-4">Putaran 3</h3></div>
                    <div class="flex flex-row flex-wrap lg:flex-nowrap gap-2">
                        <div class="basis-full flex flex-wrap bg-[#202124]">
                            <?php if(auth()->guard()->check()): ?>
                                <?php $__currentLoopData = $myguess3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                    <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                    <div class="flex flex-wrap">
                                        <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                            <li class="mb-2 flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                            </li>
                                            <li class="flex items-center">
                                                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                            </li>
                                        </ul>
                                        <div class="basis-1/2 flex items-center justify-center">
                                            <ul class="score">
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                </li>
                                                <li class="flex items-center justify-center">
                                                    <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                </li>
                                            </ul>
                                            <?php
                                                $datetime = date($match->match_time);
                                                $timestamp = strtotime($datetime);
                                                $time = $timestamp - (1 * 60 * 60);
                                                $datetime = date("Y-m-d H:i:s", $time);

                                                $d1 = new DateTime($currentTime);
                                                $d2 = new DateTime($datetime);
                                            ?>
                                            <?php if($d1 < $d2): ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php elseif($match->guessing_result == 0): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($match->is_guess == 1): ?>
                                                    <?php if($match->guessing_result == 1): ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <div class="flex items-center ml-2">
                                                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                        <div>
                                                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $matches3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="basis-full lg:basis-1/4 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
                                        <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                        <div class="flex flex-wrap">
                                            <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                <li class="mb-2 flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                </li>
                                                <li class="flex items-center">
                                                    <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                    <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                </li>
                                            </ul>
                                            <div class="basis-1/2 flex items-center justify-center">
                                                <ul class="score">
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                    </li>
                                                    <li class="flex items-center justify-center">
                                                        <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="overflow-auto ">
                    <div class="flex flex-row w-[1200px] lg:w-full ">
                        <div class="basis-full flex flex-wrap bg-[#202124] py-4 px-4">
                            <div class="w-full">
                                <div class="tournament-headers">
                                <h3 class="font-sans uppercase">Round of 16</h3>
                                <h3 class="font-sans uppercase">Quarter Finals</h3>
                                <h3 class="font-sans uppercase">Semi Finals</h3>
                                <h3 class="font-sans uppercase">Final</h3>
                                </div>

                                <div class="tournament-brackets">
                                <ul class="bracket bracket-1">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php $__currentLoopData = $myguessRound16; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="team-item">
                                                <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                                <div class="flex flex-wrap">
                                                    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                        <li class="mb-2 flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                        </li>
                                                        <li class="flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                        </li>
                                                    </ul>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $match_round_16; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="team-item">
                                            <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]"><?php echo e($match->round); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                            <div class="flex flex-wrap">
                                                <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                    <li class="mb-2 flex items-center">
                                                        <?php if($match->team1 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                    </li>
                                                    <li class="flex items-center">
                                                        <?php if($match->team2 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                    </li>
                                                </ul>
                                                <?php if($match->team1 !== 'NA'): ?>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <div class="flex items-center ml-2">
                                                                <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                <div>
                                                                    <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                    <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                                <ul class="bracket bracket-2">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php $__currentLoopData = $myguessQuarter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="team-item">
                                                <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                                <div class="flex flex-wrap">
                                                    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                        <li class="mb-2 flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                        </li>
                                                        <li class="flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                        </li>
                                                    </ul>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $match_quarter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="team-item">
                                            <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]"><?php echo e($match->round); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                            <div class="flex flex-wrap">
                                                <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                    <li class="mb-2 flex items-center">
                                                        <?php if($match->team1 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                    </li>
                                                    <li class="flex items-center">
                                                        <?php if($match->team2 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                    </li>
                                                </ul>
                                                <?php if($match->team1 !== 'NA'): ?>
                                                <div class="basis-1/2 flex items-center justify-center">
                                                    <ul class="score">
                                                        <li class="flex items-center justify-center">
                                                            <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                        </li>
                                                        <li class="flex items-center justify-center">
                                                            <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                        </li>
                                                    </ul>
                                                    <?php
                                                        $datetime = date($match->match_time);
                                                        $timestamp = strtotime($datetime);
                                                        $time = $timestamp - (1 * 60 * 60);
                                                        $datetime = date("Y-m-d H:i:s", $time);

                                                        $d1 = new DateTime($currentTime);
                                                        $d2 = new DateTime($datetime);
                                                    ?>
                                                    <?php if($d1 < $d2): ?>
                                                        <?php if($match->is_guess == 1): ?>
                                                            <?php if($match->guessing_result == 1): ?>
                                                            <div class="flex items-center ml-2">
                                                                <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                <div>
                                                                    <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                    <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                </div>
                                                            </div>
                                                            <?php elseif($match->guessing_result == 0): ?>
                                                            <div class="flex items-center ml-2">
                                                                <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                <div>
                                                                    <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                    <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <div class="flex items-center ml-2">
                                                            <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                            <div>
                                                                <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                                <ul class="bracket bracket-3">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php $__currentLoopData = $myguessSemiFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="team-item">
                                                <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                                <div class="flex flex-wrap">
                                                    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                        <li class="mb-2 flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                        </li>
                                                        <li class="flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                        </li>
                                                    </ul>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $match_semi_finals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="team-item">
                                            <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]"><?php echo e($match->round); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                            <div class="flex flex-wrap">
                                                <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                    <li class="mb-2 flex items-center">
                                                        <?php if($match->team1 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                    </li>
                                                    <li class="flex items-center">
                                                        <?php if($match->team2 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                    </li>
                                                </ul>
                                                <?php if($match->team1 !== 'NA'): ?>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <div class="flex items-center ml-2">
                                                                <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                <div>
                                                                    <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                    <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                                <ul class="bracket bracket-4">
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php $__currentLoopData = $myguessFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="team-item">
                                                <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                                <div class="flex flex-wrap">
                                                    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                        <li class="mb-2 flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                        </li>
                                                        <li class="flex items-center">
                                                            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                        </li>
                                                    </ul>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <div class="flex items-center ml-2">
                                                                <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                <div>
                                                                    <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                    <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $match_final; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="team-item">
                                            <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]"><?php echo e($match->round); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
                                            <div class="flex flex-wrap">
                                                <ul class="basis-1/2 border-r-[1px] border-[#383838]">
                                                    <li class="mb-2 flex items-center">
                                                        <?php if($match->team1 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
                                                    </li>
                                                    <li class="flex items-center">
                                                        <?php if($match->team2 == 'NA'): ?>
                                                        <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
                                                        <?php else: ?>
                                                        <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                                                        <?php endif; ?>
                                                        <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
                                                    </li>
                                                </ul>
                                                <?php if($match->team1 !== 'NA'): ?>
                                                    <div class="basis-1/2 flex items-center justify-center">
                                                        <ul class="score">
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_a); ?></p>
                                                            </li>
                                                            <li class="flex items-center justify-center">
                                                                <p class="text-[#6D6D6D] font-sans text-[22px] font-bold leading-tight"><?php echo e($match->score_b); ?></p>
                                                            </li>
                                                        </ul>
                                                        <?php
                                                            $datetime = date($match->match_time);
                                                            $timestamp = strtotime($datetime);
                                                            $time = $timestamp - (1 * 60 * 60);
                                                            $datetime = date("Y-m-d H:i:s", $time);

                                                            $d1 = new DateTime($currentTime);
                                                            $d2 = new DateTime($datetime);
                                                        ?>
                                                        <?php if($d1 < $d2): ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php elseif($match->guessing_result == 0): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($match->is_guess == 1): ?>
                                                                <?php if($match->guessing_result == 1): ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <div class="flex items-center ml-2">
                                                                    <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                                                                    <div>
                                                                        <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                                                        <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-14 pb-8">
                <img alt="logo extra joss" class="m-auto mb-2" src="<?php echo e(asset('/images/logo.png')); ?>"/>
                <p class="font-sans text-center text-[10px]">Copyright © 2022 ExtraJoss</p>
            </div>
        </section>
    </header>
    <div class="h-[1300px] z-10 absolute bottom-0">
        <img class="w-full object-cover h-full" src="<?php echo e(asset('/images/bg-lap.png')); ?>"/>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<main>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web/components/layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/web/pages/hasil.blade.php ENDPATH**/ ?>