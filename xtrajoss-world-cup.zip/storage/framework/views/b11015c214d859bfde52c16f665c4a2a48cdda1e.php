<div class="basis-full lg:basis-1/2 border-b-[1px] border-r-[1px] border-[#383838] px-4 py-6">
    <span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e($match->match_time); ?></span>
    <div class="flex flex-wrap">
        <ul class="basis-1/2 border-r-[1px] border-[#383838]">
            <li class="mb-2 flex items-center">
                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
                <p class="text-white font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
            </li>
            <li class="flex items-center">
                <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
                <p class="text-white font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
            </li>
        </ul>
        <div class="basis-1/2 flex items-center justify-center">
            <?php
                $datetime = date($match->match_time);
                $timestamp = strtotime($datetime);
                $time = $timestamp - (1 * 60 * 60);
                $datetime = date("Y-m-d H:i:s", $time);

                $d1 = new DateTime($currentTime);
                $d2 = new DateTime($datetime);
            ?>
            <?php if($d1 < $d2): ?>
                
                <?php if($match->is_guess == 0): ?>
                
                <?php echo e($match->is_guess); ?>

                <div data-idMatch=<?php echo e($match->id_match); ?> data-flag1=<?php echo e($match->flag_team1); ?> data-flag2=<?php echo e($match->flag_team2); ?> data-team1=<?php echo e($match->team1); ?> data-team2=<?php echo e($match->team2); ?> class="btn-tebak bg-[#FF0000] text-white text-[12px] rounded-2xl py-1 px-2 w-[100px] text-center cursor-pointer">Tebak Skor</div>
                <?php else: ?>
                
                <ul class="score">
                    <li class="flex items-center">
                        <p class="text-white font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                    </li>
                    <li class="flex items-center">
                        <p class="text-white font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                    </li>
                </ul>
                <div data-idMatch=<?php echo e($match->id_match); ?> data-skor="<?php echo e($match->guessing_score_a); ?>,<?php echo e($match->guessing_score_b); ?>" data-flag1=<?php echo e($match->flag_team1); ?> data-flag2=<?php echo e($match->flag_team2); ?> data-team1=<?php echo e($match->team1); ?> data-team2=<?php echo e($match->team2); ?> class="btn-tebak cursor-pointer bg-[#0085CF] text-white text-[12px] rounded-2xl py-1 px-2 w-[94px] text-center">Edit Skor</div>
                <?php endif; ?>
            <?php else: ?>
                <?php if($match->is_guess == 1): ?>
                    <?php if($match->guessing_result == 1): ?>
                    <ul class="score">
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                        </li>
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                        </li>
                    </ul>
                    <div class="flex items-center ml-4">
                        <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                        <div>
                            <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                            <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                        </div>
                    </div>
                    <?php else: ?>
                    
                    <ul class="score">
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                        </li>
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                        </li>
                    </ul>
                    <div class="bg-[#6D6D6D] text-white text-[12px] rounded-2xl py-1 px-2 w-[94px] text-center">Edit Skor</div>
                    <?php endif; ?>
                <?php else: ?>
                    
                    <ul class="score">
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight">0</p>
                        </li>
                        <li class="flex items-center">
                            <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight">0</p>
                        </li>
                    </ul>
                    <div class="flex items-center ml-4">
                        <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                        <div>
                            <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                            <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/web/components/presentational/guessBox.blade.php ENDPATH**/ ?>