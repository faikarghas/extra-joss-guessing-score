<?php if($round[0]->id == 4): ?>
<span class="block mb-2.5 text-[16px] font-sans text-[#acacac]"><?php echo e($match->round); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
<?php else: ?>
<span class="block mb-2.5 text-[16px] font-sans text-[#acacac]">Group <?php echo e($match->group); ?> • <?php echo e(date('M d, H:i', strtotime($match->match_time))); ?></span>
<?php endif; ?>

<div class="flex flex-wrap">
    <?php if($match->team1 !== 'NA'): ?>
    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
        <li class="mb-2 flex items-center">
            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
        </li>
        <li class="flex items-center">
            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
        </li>
    </ul>
    <?php else: ?>
    <ul class="basis-1/2 border-r-[1px] border-[#383838]">
        <li class="mb-2 flex items-center">
            <?php if($match->team1 == 'NA'): ?>
            <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
            <?php else: ?>
            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team1); ?>" class="h-[30px]"/>
            <?php endif; ?>
            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team1); ?></p>
        </li>
        <li class="flex items-center">
            <?php if($match->team2 == 'NA'): ?>
            <div class="rounded-full w-[30px] h-[30px] bg-[#989CA5]"></div>
            <?php else: ?>
            <img src="<?php echo e(asset('/images/countries')); ?>/<?php echo e($match->flag_team2); ?>" class="h-[30px]"/>
            <?php endif; ?>
            <p class="text-[#989CA5] font-bold font-sans ml-1.5 text-[15px] leading-tight"><?php echo e($match->team2); ?></p>
        </li>
    </ul>
    <?php endif; ?>
    <div class="basis-1/2 flex items-center justify-center">
        <?php
            $datetime = date($match->match_time);
            $timestamp = strtotime($datetime);
            $time = $timestamp - (1 * 60 * 60);
            $datetime = date("Y-m-d H:i:s", $time);

            $d1 = new DateTime($currentTime);
            $d2 = new DateTime($datetime);
        ?>
        <?php if($match->team1 !== 'NA'): ?>
            <?php if($d1 < $d2): ?>
                
                <?php if($match->is_guess == 0): ?>
                
                <div data-idMatch="<?php echo e($match->id_match); ?>" data-flag1="<?php echo e($match->flag_team1); ?>" data-flag2="<?php echo e($match->flag_team2); ?>" data-team1=<?php echo e($match->team1); ?> data-team2=<?php echo e($match->team2); ?> class="btn-tebak bg-[#FF0000] text-white text-[12px] rounded-2xl py-1 px-2 w-[100px] text-center cursor-pointer">Tebak Skor</div>
                <?php else: ?>
                
                <ul class="score">
                    <li class="flex items-center">
                        <p class="text-[#6D6D6D] font-bold font-sans mr-4 text-[22px] leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                    </li>
                    <li class="flex items-center">
                        <p class="text-[#6D6D6D] font-bold font-sans mr-4 text-[22px] leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                    </li>
                </ul>
                <div data-idMatch="<?php echo e($match->id_match); ?>" data-skor="<?php echo e($match->guessing_score_a); ?>,<?php echo e($match->guessing_score_b); ?>" data-flag1=<?php echo e($match->flag_team1); ?> data-flag2=<?php echo e($match->flag_team2); ?> data-team1=<?php echo e($match->team1); ?> data-team2=<?php echo e($match->team2); ?> class="btn-tebak cursor-pointer bg-[#0085CF] text-white text-[12px] rounded-2xl py-1 px-2 w-[94px] text-center">Edit Skor</div>
                <?php endif; ?>
            <?php else: ?>
                
                <?php if($match->team1 !== 'NA'): ?>
                    <?php if($match->is_guess == 1): ?>
                        <?php if($match->guessing_result == 1): ?>
                            
                            <ul class="score">
                                <li class="flex items-center">
                                    <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                                </li>
                                <li class="flex items-center">
                                    <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                                </li>
                            </ul>
                            <div class="flex items-center ml-4">
                                <img src="<?php echo e(asset('images/acvcolor.png')); ?>" class="h-[35px]"/>
                                <div>
                                    <span class="block font-sans text-[10px] text-[#FFA800]">Anda dapat</span>
                                    <span class="block font-sans text-[12px] font-bold text-[#FFA800]">1000 Poin</span>
                                </div>
                            </div>
                        <?php elseif($match->guessing_result == 0): ?>
                        
                        <ul class="score">
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                            </li>
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                            </li>
                        </ul>
                        <div class="flex items-center ml-4">
                            <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                            <div>
                                <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                            </div>
                        </div>
                        <?php else: ?>
                        <ul class="score">
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_a); ?></p>
                            </li>
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans mr-4 text-[22px] font-bold leading-tight"><?php echo e($match->guessing_score_b); ?></p>
                            </li>
                        </ul>
                        <div class="cursor-pointer bg-[#6D6D6D] text-white text-[12px] rounded-2xl py-1 px-2 w-[94px] text-center">Edit Skor</div>
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <ul class="score">
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight">0</p>
                            </li>
                            <li class="flex items-center">
                                <p class="text-[#6D6D6D] font-sans ml-4 text-[22px] font-bold leading-tight">0</p>
                            </li>
                        </ul>
                        <div class="flex items-center ml-4">
                            <img src="<?php echo e(asset('images/acvgrey.png')); ?>" class="h-[35px]"/>
                            <div>
                                <span class="block font-sans text-[10px] text-[#6D6D6D]">Anda dapat</span>
                                <span class="block font-sans text-[12px] font-bold text-[#6D6D6D]">0 Poin</span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

<?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/web/components/presentational/guessBoxWithLogic.blade.php ENDPATH**/ ?>