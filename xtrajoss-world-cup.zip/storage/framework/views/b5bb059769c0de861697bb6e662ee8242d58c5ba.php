
<?php $__env->startSection('title'); ?>
  Matches Add 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
  <?php echo e(Breadcrumbs::render('add_category')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form  action="<?php echo e(route('matchs.update',$fmatch->id)); ?>" method="POST">
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
   <div class="row">
      <div class="col-md-8">
         <div class="card mb-4">
            <h5 class="card-header">Match Add</h5>
            <div class="card-body">
               <div class="mb-3">
                  <label for="exampleFormControlSelect1" class="form-label">Team A</label>
                  <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="id_team_a">
                    <option value="">Select Country A</option>
                    
                    <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($row->id == $fmatch->id_team_a): echo 'selected'; endif; ?> value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
               <div class="mb-3">
                  <label for="exampleFormControlSelect1" class="form-label">Team B</label>
                  <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="id_team_b">
                    <option value="">Select Country B</option>
                    <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($row->id == $fmatch->id_team_b): echo 'selected'; endif; ?> value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
               <div class="mb-3">
                  <label for="html5-datetime-local-input" class="col-md-2 col-form-label">Match Time</label>
                  <div>
                     <input
                        class="form-control"
                        type="datetime-local"
                        id="html5-datetime-local-input"
                        name="match_time"
                        value="<?php echo e(old('match_time', $fmatch->match_time)); ?>"
                     />
                  </div>
               </div>
               <div class="mb-3">
                  <label for="defaultFormControlInput" class="form-label">Result Team 1</label>
                  <input
                     type="text"
                     class="form-control"
                     id="defaultFormControlInput"
                     placeholder="John Doe"
                     aria-describedby="defaultFormControlHelp"
                     name="score_a"
                     value="<?php echo e(old('score_a', $fmatch->score_a)); ?>"
                  />
               </div>
               <div class="mb-3">
                  <label for="defaultFormControlInput" class="form-label">Result Team 2</label>
                  <input
                     type="text"
                     class="form-control"
                     id="defaultFormControlInput"
                     placeholder="John Doe"
                     aria-describedby="defaultFormControlHelp"
                     name="score_b"
                     value="<?php echo e(old('score_b', $fmatch->score_b)); ?>"
                  />
               </div>
               <button type="submit" class="btn btn-primary">SAVE</button>
            </div>
         </div>
      </div>
      <div class="col-md-4">
         <div class="card mb-4">
            <h5 class="card-header">Match Setings</h5>
            <div class="card-body">
               <div class="mb-3">
                  <label for="exampleFormControlSelect1" class="form-label">ROUND</label>
                  <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="round">
                    <option value="">Select Round</option>
                    <?php $__currentLoopData = $round; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option <?php if($row->id == $fmatch->round): echo 'selected'; endif; ?>
                           value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

               </div>
               <div class="mb-3">
                  <label for="exampleFormControlSelect1" class="form-label">STATUS</label>
                  <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" name="match_status">
                    <option value="">Select Status</option>
                    <?php $__currentLoopData = $match_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('match_status',  $fmatch->match_status) == $key ? "selected" : null); ?>> <?php echo e($value); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </select>
               </div>
            </div>
         </div>
      </div>
   </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript-external'); ?>
  <script src="<?php echo e(asset('vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/tinymce5/jquery.tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/tinymce5/tinymce.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('javascript-internal'); ?>
 <script>
   $(document).ready(function(){
      $("#input_post_title").change(function (event) {
         $("#input_post_slug").val(
            event.target.value
               .trim()
               .toLowerCase()
               .replace(/[^a-z\d-]/gi, "-")
               .replace(/-+/g, "-")
               .replace(/^-|-$/g, "")
         );
      });
      // event : input thumbnail with file manager and description
      $('#button_post_thumbnail').filemanager('image');
      $('#button_post_image').filemanager('image');
      // event :  description

      // tinymce for content
      $("#input_post_content").tinymce({
         relative_urls: false,
         language: "en",
         plugins: [
            "advlist autolink lists link image charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen",
            "insertdatetime media nonbreaking save table directionality",
            "emoticons template paste textpattern",
         ],
         forced_root_block : '',
         toolbar1: "fullscreen preview",
         toolbar2:
            "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
            file_picker_callback: function(callback, value, meta) {
               let x = window.innerWidth || document.documentElement.clientWidth || document
                  .getElementsByTagName('body')[0].clientWidth;
               let y = window.innerHeight || document.documentElement.clientHeight || document
                  .getElementsByTagName('body')[0].clientHeight;

               let cmsURL = "<?php echo e(route('unisharp.lfm.show')); ?>" + '?editor=' + meta.fieldname;
               if (meta.filetype == 'image') {
                  cmsURL = cmsURL + "&type=Images";
               } else {
                  cmsURL = cmsURL + "&type=Files";
               }
               tinyMCE.activeEditor.windowManager.openUrl({
                  url: cmsURL,
                  title: 'Filemanager',
                  width: x * 0.8,
                  height: y * 0.8,
                  resizable: "yes",
                  close_previous: "no",
                  onMessage: (api, message) => {
                     callback(message.content);
                  }
               });
            }
         });

         $("#btn-add-post-images").click(function(){ 
            var hmtl = $(".clone").html();
            $(".increment").after(hmtl);
         });
         $("body").on("click",".btn-danger",function(){ 
            $(this).parents(".control-group").remove();
         });
      });

 </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/admin/match/edit.blade.php ENDPATH**/ ?>