
<?php $__env->startSection('meta-tag'); ?>
<title></title>
<meta name="description" content="meta description">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="relative h-full">
    <header class="relative  info bg-no-repeat bg-cover bg-[#FFEC00]" >
        <?php echo $__env->make('web.components.presentational.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <section class="relative z-20 m-auto lg:w-[95%] pt-[85px] sm:pt-[130px] lg:pt-[160px]">
            <div class="bg-[#FCF006] lg:bg-[#F8F8F8] px-12 pt-8 pb-28 flex flex-col">
                <h1 class="text-black text-[60px] font-head mb-8 leading-[50px]">MEKANISME</h1>
                <div class="flex flex-col content">
                  <?php echo $mekanisme[0]->content; ?>

                </div>
            </div>

            <div class="pt-14 pb-8">
                <img alt="logo extra joss" class="m-auto mb-2" src="<?php echo e(asset('/images/logo.png')); ?>"/>
                <p class="font-sans text-center text-[10px]">Copyright © 2022 ExtraJoss</p>
            </div>
        </section>
    </header>
    <div class="h-[1300px] z-10 absolute bottom-0">
        <img class="w-full object-cover h-full" src="<?php echo e(asset('/images/bg-lap.png')); ?>"/>
    </div>
    <div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<main>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web/components/layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\xtrajoss-world-cup\resources\views/web/pages/mekanisme.blade.php ENDPATH**/ ?>